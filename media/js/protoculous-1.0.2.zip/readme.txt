	===============
	= Protoculous =
	===============

	Version 1.0.2

	Changelog
	---------
	2007-06-02: - Update of protoculous including Scriptaculous 1.7.1 beta 3
		    - Added a 
	2007-05-05: First version of protocumous uploaded !

	The archive contains some files :
	- prototype-x.x.x-formatted.js : Prototype with semicolons and correct syntax, provided in protopacked : http://groups.google.com/group/prototype-core/files
	- scriptaculous-x.x.x.js : shrinked version of scriptaculous containing builder,controls,dragdrop,effects,slider and sound components
	- protoculous-x.x.x-shrinked.js : Shrinked version of prototype and scriptaculous together
	- protoculous-x.x.x-shrinked _variables.js : Hard shrinked version of protoculous (replacing name of variables)
	- protoculous-x.x.x-packed.js : Bigger file than protoculous-x.x.x.js but could avoid problems with a few websites and a few browsers
	- protoculous-x.x.x.js : Smallest protoculous file using Real File Compression
	
	If you have some questions, suggestion and so on, please send me an email to bistory@gmail.com
	I'm french, so you can send me an email in english or in french, as you want !
	
	Note :
	If you use the protoculous-x.x.x.js file, don't forget to define charset:
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">

	Thanks !
	
	Librairies compressed are :
	Prototype : http://www.prototypejs.org
	Scriptaculous : http://script.aculo.us	

	Tools used to compile the both librairies :
	Dojo ShrinkSafe : http://alex.dojotoolkit.org/shrinksafe/
	Dean Edward's Packer (beta 9) : http://dean.edwards.name/packer/
	Bananascript.com (version of the 2007-04-28) : http://www.bananascript.com/
	
	Special thanks to "the guy who compressed protopacked" who gave me advices and tips (and who speaks about me in his readme !).